#include "DictClient.h"

int main() {
    DictClient().StartSession();
}
